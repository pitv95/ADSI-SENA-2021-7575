<?php
$cestudiate=$_POST['cestudiante'];
$nestudiante=$_POST['nestudiante'];
$nmateria=$_POST['nmateria'];
$nota1=$_POST['nota1'];
$nota2=$_POST['nota2'];
$nota3=$_POST['nota3'];
$resultado="";
$mensaje="";
$promedio= ($nota1 + $nota2 + $nota3)/3;
if ($promedio >=4){
$resultado="Aprobado";
}
else {
$resultado="Reprobado";
}

$mensaje = $mensaje . "El codigo del estudiante es: " . $cestudiate . "<br>";
$mensaje = $mensaje . "El nombre del estudiante es: ". $nestudiante . "<br>"; 
$mensaje = $mensaje . "El nombre de la materia es: ". $nmateria . "<br>"; 
$mensaje = $mensaje . "La nota final del estudiante es: ". $promedio . "<br>"; 
$mensaje = $mensaje . "El estudiante se encuentra: " . $resultado ."<br>";
echo $mensaje;
?>