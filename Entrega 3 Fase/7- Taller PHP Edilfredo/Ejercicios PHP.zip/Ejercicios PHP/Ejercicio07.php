<?php

$minutos=0;
$segundos=0;

for ($horas=0; $horas <= 23 ; $horas++) { 
    for ($minutos=0; $minutos <=59 ; $minutos++) { 
        for ($segundos=0; $segundos <= 59; $segundos++) { 
            echo"La hora es ".$horas .":".$minutos.":". $segundos . "<br>";        }
    }
} 
?>