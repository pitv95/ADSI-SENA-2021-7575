<?php
$numero =$_POST['numero'];
$contador=0;
$suma=0;
do {
    $suma=$suma + $contador;
    echo "el numero naturale es:  ".$contador ."<br/>";
    $contador++;
} while ($contador < $numero);

echo "la suma de los numeros naturales es: ".$suma ."<br/>";
?>