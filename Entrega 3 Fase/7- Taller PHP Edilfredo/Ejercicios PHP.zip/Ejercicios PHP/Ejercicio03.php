<?php
$edad=$_POST['edad'];
$peso =$_POST['peso'];
$estatura=$_POST['estatura'];
if ($edad <= 18 && $estatura >= 180 && $peso <= 80){
    echo "Bienvenido a Coldeportes";
}
else{
    echo "Usted no cumple con los requisitos";

}
?>
