<?php
$numero = 1;
$factorial = 1;
$tope =$_POST['tope'];

while ($numero <= $tope){
	$factorial = $factorial * $numero;
	$numero++;
}
echo "El factorial de " . $tope . " es: " . $factorial;
?>	