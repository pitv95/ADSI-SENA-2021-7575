<?php
$numero=$_POST['numero'];
$resultado = 0;
for ($contador=1; $contador <= 10 ; $contador++) { 
    $resultado = $numero * $contador;
    echo "la multiplicación de " . $numero . "x" . $contador . "es: " . $resultado . "<br>";
}
?>
