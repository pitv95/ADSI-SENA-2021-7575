<?php

$lunes=$_POST['lunes'];
$martes=$_POST['martes'];
$miercoles=$_POST['miercoles'];
$jueves=$_POST['jueves'];
$viernes=$_POST['viernes'];
$sabado=$_POST['sabado'];
$domingo=$_POST['domingo'];
$totaltemperatura=0;

$totaltemperatura = ($lunes + $martes + $miercoles + $jueves + $viernes + $sabado + $domingo)/ 7;

if ($totaltemperatura > 35){
    echo "Que semana Tan Calurosa";
}

if ($totaltemperatura < 15) {
echo "Que semana tan fría";
}else{
echo "Que clima tan delicioso ";
}
?>
