<?php
$salarioH =$_POST['salarioH'];
$salarioE =$_POST['salarioE'];
$horasT =$_POST['horasT'];
$salarioT=0;
$cantidadE=0;
$salarioTE=0;
$descuento=0.25;
if ($horasT > 40) {
    $cantidadE = $horasT - 40;
    $salarioTE= $cantidadE * $salarioE;
    $salarioT = ($horasT - $cantidadE) * $salarioH + $salarioTE;
}else {
    $salarioT = $horasT * $salarioH;
}

$descuento = $salarioT * 0.25;
$salarioT = $salarioT - $descuento;
echo "su salario total es: " . $salarioT;

?>