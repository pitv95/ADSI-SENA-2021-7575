<?php
$nllantas=$_POST['nllantas'];
$vllantas=0;
if ($nllantas < 5){
    $vllantas = $nllantas * 30000;
}
elseif ($nllantas >5 && $nllantas <= 10) {
$vllantas = $nllantas * 25000;
}
else{
$vllantas = $nllantas * 20000;
}
echo"El valor total a pagar es: " . $vllantas;
?>